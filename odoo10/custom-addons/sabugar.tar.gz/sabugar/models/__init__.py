# -*- Coding: utf-8 -*-

import res_partner
