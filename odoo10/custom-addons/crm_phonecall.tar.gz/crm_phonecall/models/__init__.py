# -*- coding: utf-8 -*-
# Copyright 2017 Tecnativa - Vicent Cubells
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import crm_phonecall
from . import calendar
from . import res_partner
from . import crm_lead
